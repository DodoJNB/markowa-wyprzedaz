/* =========================================================
   ya_kub — front-end logic
   NOTE: YouTube / TikTok / Kick do not allow anonymous
   browser JS to read channel data directly (no key / CORS).
   In production this data should come from a small backend
   (a few lines of Node/PHP) that calls the official APIs and
   caches the result. Below is a best-effort client version:
   it tries a couple of public, keyless endpoints and falls
   back to a friendly "open the channel" state if they fail,
   so the page never looks broken.
   ========================================================= */

const HANDLES = {
  youtube: '@ya_kubb',
  tiktok: '@ya_kub',
  kick: 'ya-kub',
  instagram: 'ya_kuuub',
  discord: 'https://discord.gg/vAHj8Z5WWD',
  tipply: 'https://tipply.pl/@ya_kub',
  casehug: 'https://casehug.com/r/YA_KUB'
};

/* ---------- copy code buttons ---------- */
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-copy-code]');
  if (!btn) return;
  const code = btn.getAttribute('data-copy-code') || '';
  if (!code || !navigator.clipboard) return;
  navigator.clipboard.writeText(code).then(() => {
    btn.classList.add('is-copied');
    const small = btn.querySelector('small');
    const prev = small.textContent;
    small.textContent = 'SKOPIOWANO';
    setTimeout(() => {
      btn.classList.remove('is-copied');
      small.textContent = prev;
    }, 1500);
  });
});

/* ---------- YouTube: latest uploads via public RSS feed ---------- */
async function loadYouTube() {
  const grid = document.getElementById('ytGrid');
  if (!grid) return;
  try {
    const channelRes = await fetch(
      `https://r.jina.ai/https://www.youtube.com/${HANDLES.youtube}`,
      { signal: AbortSignal.timeout(6000) }
    );
    if (!channelRes.ok) throw new Error('channel lookup failed');
    const html = await channelRes.text();
    const match = html.match(/"channelId":"(UC[0-9A-Za-z_-]{22})"/);
    if (!match) throw new Error('channel id not found');
    const channelId = match[1];

    const subsMatch = html.match(/([\d.,]+\s?(?:tys\.|mln|K|M)?)\s*subskrybent/i);
    const statYt = document.getElementById('statYt');
    if (statYt && subsMatch) statYt.textContent = subsMatch[1].trim();

    const feedRes = await fetch(
      `https://r.jina.ai/https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`,
      { signal: AbortSignal.timeout(6000) }
    );
    if (!feedRes.ok) throw new Error('feed failed');
    const xmlText = await feedRes.text();
    const parser = new DOMParser();
    const xml = parser.parseFromString(xmlText, 'text/xml');
    const entries = Array.from(xml.querySelectorAll('entry')).slice(0, 6);
    if (!entries.length) throw new Error('no entries');

    grid.innerHTML = '';
    entries.forEach((entry) => {
      const videoId = entry.querySelector('videoId')?.textContent
        || entry.querySelector('id')?.textContent?.split(':').pop();
      const title = entry.querySelector('title')?.textContent || 'Nowy film';
      const published = entry.querySelector('published')?.textContent;
      const date = published ? new Date(published).toLocaleDateString('pl-PL') : '';
      const thumb = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;

      grid.insertAdjacentHTML('beforeend', `
        <a class="card video-card" href="https://www.youtube.com/watch?v=${videoId}" target="_blank" rel="noreferrer">
          <div class="video-thumb">
            <img src="${thumb}" alt="" loading="lazy">
            <div class="video-play">
              <svg viewBox="0 0 24 24" fill="#ff0000"><circle cx="12" cy="12" r="12" fill="rgba(12,14,19,.55)"/><path d="M10 8.5l6 3.5-6 3.5v-7z" fill="#fff"/></svg>
            </div>
          </div>
          <div class="video-body">
            <div class="video-title">${escapeHtml(title)}</div>
            <div class="video-meta">${date}</div>
          </div>
        </a>
      `);
    });
  } catch (err) {
    grid.innerHTML = `
      <div class="platform-empty">
        Nie udało się pobrać najnowszych filmów automatycznie.
        <br><a class="btn btn-ghost" style="margin-top:14px" href="https://www.youtube.com/${HANDLES.youtube}/videos" target="_blank" rel="noreferrer">Zobacz filmy na YouTube</a>
      </div>`;
  }
}

/* ---------- Kick: live status via public status endpoint ---------- */
async function loadKick() {
  const dots = [document.getElementById('kickStatusDot'), document.getElementById('kickStatusDot2')];
  const texts = [document.getElementById('kickStatusText'), document.getElementById('kickStatusText2')];
  const statusTitle = document.getElementById('kickStreamTitle');
  const statKick = document.getElementById('statKick');
  if (!texts[0] && !texts[1]) return;

  const setAll = (nodes, value) => nodes.forEach((n) => { if (n) n.textContent = value; });
  const setLive = (isLive) => dots.forEach((d) => { if (d) d.classList.toggle('live', isLive); });

  try {
    const res = await fetch(`https://kick.com/api/v2/channels/${HANDLES.kick}`, {
      signal: AbortSignal.timeout(6000)
    });
    if (!res.ok) throw new Error('kick api failed');
    const data = await res.json();
    const isLive = !!data?.livestream;
    setLive(isLive);
    setAll(texts, isLive ? 'Na żywo teraz' : 'Offline');
    if (statusTitle) {
      statusTitle.textContent = isLive
        ? (data.livestream.session_title || 'Trwa transmisja')
        : 'Sprawdź kanał, żeby nie przegapić streamu.';
    }
    if (statKick && typeof data?.followersCount === 'number') {
      statKick.textContent = data.followersCount.toLocaleString('pl-PL');
    }
  } catch (err) {
    setAll(texts, 'Status niedostępny');
    if (statusTitle) statusTitle.textContent = 'Otwórz Kick, żeby sprawdzić, czy trwa transmisja.';
  }
}

/* ---------- TikTok: latest video via oEmbed (needs a known video URL) ---------- */
function initTikTokFallback() {
  const grid = document.getElementById('tiktokGrid');
  if (!grid) return;
  grid.innerHTML = `
    <div class="platform-empty">
      Najnowsze filmy z TikToka nie ładują się automatycznie w tej wersji strony
      (TikTok nie udostępnia publicznego API bez klucza).
      <br><a class="btn btn-ghost" style="margin-top:14px" href="https://www.tiktok.com/${HANDLES.tiktok}" target="_blank" rel="noreferrer">Zobacz TikToka</a>
    </div>`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

document.addEventListener('DOMContentLoaded', () => {
  loadYouTube();
  loadKick();
  initTikTokFallback();

  const toggle = document.getElementById('navToggle');
  document.querySelectorAll('.site-nav a').forEach((a) => {
    a.addEventListener('click', () => { if (toggle) toggle.checked = false; });
  });
});
